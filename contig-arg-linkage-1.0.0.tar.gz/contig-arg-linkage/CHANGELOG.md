# Changelog

All notable changes to this pipeline will be documented in this file.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and
this project adheres to [Semantic Versioning](https://semver.org/).

## [1.0.0] — 2026-05-09

First public release alongside the PREVAIL dissertation.

### Added
- Snakemake 8 workflow replacing the original SLURM array bash script
- Per-rule conda environments with pinned versions
- Apptainer + Docker container definitions
- SLURM execution profile (replaces hand-rolled `sbatch` directives)
- Deterministic synthetic test dataset (`tests/build_test_data.py`)
- GitHub Actions CI: smoke test + linters (shellcheck, ruff, snakefmt)
- `scripts/download_databases.sh` with SHA256 verification
- Run-provenance manifest (git commit + DB checksums + tool versions)
  written into every results directory
- JSON Schema for config validation

### Changed
- ARG linker (`workflow/scripts/link_args.py`) refactored:
  - Snakemake `script:` directive entry point + standalone CLI
  - Generator-based BLAST hit parsing (constant memory for huge hit files)
  - Type hints throughout
- Output goes to `results/06_contig_amr/` by default; intermediate files
  use Snakemake's `temp()` so they're auto-cleaned

### Database versions used in published runs
- MEGARes 3.0.0 (2022-01-04)
- Kraken2 Standard `k2_standard_20240605` (Ben Langmead pre-built)

## [0.x] — pre-release (PREVAIL internal use, 2024–2025)

- Original `06_contig_amr.sh` array script + `06_link_args.py`
  (preserved in git history for archival reference)
