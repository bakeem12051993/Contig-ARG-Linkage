# Contributing

Thanks for your interest. This pipeline is research software developed for
the PREVAIL birth cohort dissertation; it is maintained on a best-effort
basis. Bug reports, feature requests, and pull requests are welcome.

## Reporting bugs

Open an issue with:

1. The exact command you ran (`snakemake ...`).
2. The Snakemake + tool versions (`snakemake --version`, `python --version`,
   the contents of `results/.../run_manifest.tsv` if available).
3. The full error message + relevant log files (under `results/.../logs/`).
4. Whether you ran via conda, Apptainer, or Docker.

If you can reproduce the bug on the smoke-test data
(`bash tests/run_smoke_test.sh`), include that — it makes triage much faster.

## Submitting changes

1. Fork the repo and create a feature branch.
2. Run linters locally before pushing:
   ```bash
   shellcheck scripts/*.sh tests/*.sh profiles/slurm/*.sh
   ruff check workflow/scripts tests/build_test_data.py
   snakefmt --check workflow/
   ```
3. Run the smoke test locally (`bash tests/run_smoke_test.sh`) and confirm
   it passes.
4. Open a PR. CI must pass before merge.

## Adding new pipeline rules

1. Add a new `.smk` file under `workflow/rules/` and `include:` it from
   `workflow/Snakefile`.
2. Add a per-rule env file under `envs/` if the rule needs a tool not
   already installed.
3. Update `workflow/schemas/config.schema.yaml` if the rule reads new
   config fields.
4. Add at least one assertion to `tests/run_smoke_test.sh` exercising the
   new rule's output.

## Updating reference databases

1. Download the new database file.
2. Compute its SHA256: `sha256sum <file>`.
3. Update `config/databases.yaml` with the new version, URL, and SHA256.
4. Add an entry to `CHANGELOG.md` under "Database versions".
5. Re-run the pipeline; `run_manifest.tsv` will now show the new hash.

## Code style

- **Python**: PEP 8, enforced via `ruff`. Type hints on public functions.
- **Shell**: `set -euo pipefail` at the top of every script. shellcheck
  warnings are blocking in CI.
- **Snakemake**: `snakefmt`-compliant formatting. One rule per file when a
  rule is non-trivial, grouped into a single `.smk` file by phase otherwise.
