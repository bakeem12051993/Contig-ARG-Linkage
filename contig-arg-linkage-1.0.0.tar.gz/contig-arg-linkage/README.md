# Contig-Based ARG–Pathogen Linkage Pipeline

[![CI](https://github.com/yourusername/contig-arg-linkage/actions/workflows/ci.yml/badge.svg)](https://github.com/yourusername/contig-arg-linkage/actions/workflows/ci.yml)
[![Lint](https://github.com/yourusername/contig-arg-linkage/actions/workflows/lint.yml/badge.svg)](https://github.com/yourusername/contig-arg-linkage/actions/workflows/lint.yml)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.PLACEHOLDER.svg)](https://doi.org/10.5281/zenodo.PLACEHOLDER)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Snakemake](https://img.shields.io/badge/snakemake-≥8.0-brightgreen.svg)](https://snakemake.github.io)

A reproducible Snakemake pipeline for linking antibiotic resistance genes
(ARGs) to bacterial hosts in metagenomic data through contig
co-localization. Developed for the **PREVAIL birth cohort** study on
environmental determinants of the infant gut resistome.

## What it does

For each metagenomic sample, the pipeline:

1. **Assembles** host-removed paired-end reads into contigs (MEGAHIT)
2. **Detects ARGs** on contigs via BLASTn against MEGARes v3.0
3. **Classifies** contigs taxonomically with Kraken2
4. **Links** ARGs to taxonomy when both map to the same contig

Unlike read-based correlation approaches, contig co-localization provides
direct physical evidence that a resistance gene resides within a specific
organism's genome.

```
host-removed paired reads
        │
        ▼
   ┌──────────┐
   │ MEGAHIT  │  assemble → contigs
   └────┬─────┘
        ├───────────┐
        ▼           ▼
   ┌────────┐ ┌──────────┐
   │ BLASTn │ │ Kraken2  │
   │MEGARes │ │ Standard │
   └────┬───┘ └────┬─────┘
        │          │
        ▼          ▼
   ┌──────────────────┐
   │   join by contig │
   └────────┬─────────┘
            ▼
  {sample}_arg_contig_links.csv
```

## Requirements

| Layer | Tool |
|-------|------|
| Workflow | [Snakemake](https://snakemake.github.io) ≥ 8.0 |
| Assembly | [MEGAHIT](https://github.com/voutcn/megahit) 1.2.9 |
| ARG detection | [BLAST+](https://blast.ncbi.nlm.nih.gov/) 2.15.0 |
| Taxonomy | [Kraken2](https://github.com/DerrickWood/kraken2) 2.1.3 |
| Linking | Python 3.11 (stdlib only) |
| Container (optional) | [Apptainer](https://apptainer.org) ≥ 1.2 or Docker |
| Scheduler (optional) | SLURM |

All exact versions are pinned in `envs/environment.yml` and the per-rule
env files under `envs/`.

## Quick start

### Option 1 — Conda (recommended for first-time users)

```bash
git clone https://github.com/yourusername/contig-arg-linkage.git
cd contig-arg-linkage

# Create the top-level env (Snakemake + helpers)
conda env create -f envs/environment.yml
conda activate contig-arg-linkage

# Smoke test (uses synthetic data; ~5 min)
bash tests/run_smoke_test.sh

# Download production reference databases (~80 GB, ~hours)
bash scripts/download_databases.sh all

# Edit config/config.yaml + config/samples.tsv for your data
# Run the pipeline
snakemake --cores 16 --use-conda
```

### Option 2 — Apptainer (recommended for HPC / public-release runs)

```bash
# Build once
apptainer build contig-arg-linkage.sif containers/Apptainer.def

# Run
apptainer exec \
  --bind /path/to/your/data:/data \
  --bind $PWD:/work \
  --workdir /work \
  contig-arg-linkage.sif \
    snakemake --cores 16
```

### Option 3 — Docker (recommended for portable / CI runs)

```bash
docker build -f containers/Dockerfile -t contig-arg-linkage:1.0.0 .
docker run --rm -v $PWD:/work -w /work contig-arg-linkage:1.0.0 \
    --cores 8 --use-conda
```

## Repository layout

```
contig-arg-linkage/
├── workflow/
│   ├── Snakefile                    # Main entrypoint
│   ├── rules/
│   │   ├── assembly.smk             # MEGAHIT
│   │   ├── arg_detection.smk        # BLAST
│   │   ├── classification.smk      # Kraken2
│   │   └── linkage.smk              # Python join
│   ├── scripts/link_args.py         # ARG ↔ taxonomy joiner
│   └── schemas/config.schema.yaml   # Config validation
├── config/
│   ├── config.yaml                  # User-editable parameters
│   ├── samples.tsv                  # Sample manifest
│   └── databases.yaml               # DB versions + checksums
├── envs/                            # Pinned conda envs (per-rule)
├── containers/
│   ├── Apptainer.def                # HPC-friendly SIF recipe
│   └── Dockerfile                   # Docker recipe
├── profiles/slurm/                  # Snakemake SLURM profile
├── tests/
│   ├── build_test_data.py           # Deterministic synthetic dataset
│   ├── config_test.yaml
│   ├── run_smoke_test.sh
│   └── test_data.sha256             # Expected hashes for reproducibility
├── scripts/
│   └── download_databases.sh        # Reference DB installer (with checksums)
└── .github/workflows/
    ├── ci.yml                       # Smoke test on every PR
    └── lint.yml                     # shellcheck + ruff + snakefmt
```

## Configuration

### 1. Sample manifest (`config/samples.tsv`)

A tab-separated file with at least a `sample_id` column. Add whatever
metadata columns help your downstream analysis:

```tsv
sample_id	timepoint	subject_id	birth_mode
PREVAIL_001	6wk	S001	vaginal
PREVAIL_002	6wk	S002	cesarean
```

The pipeline expects, for each `sample_id`:

```
{paths.decontam}/{sample_id}_R1_decontam.fastq.gz
{paths.decontam}/{sample_id}_R2_decontam.fastq.gz
```

> **Upstream provenance:** This pipeline assumes reads have already had
> human host DNA removed (e.g., via Bowtie2 alignment to GRCh38). The
> host-removal pipeline used for PREVAIL is documented separately; future
> versions will include a `00_host_removal.smk` rule.

### 2. Pipeline parameters (`config/config.yaml`)

Edit paths under `paths:` and `databases:`. The defaults assume:

- Input reads in `data/02_host_removal/decontam/`
- Outputs in `results/06_contig_amr/`
- Databases under `databases/`

Algorithm parameters (BLAST stringency, MEGAHIT preset, Kraken2 confidence)
have sensible defaults documented inline.

### 3. Reference databases (`config/databases.yaml`)

The version manifest pins exact database releases with SHA256 checksums:

```yaml
megares:
  version: "3.0.0"
  url: "https://www.meglab.org/downloads/megares_v3.00/..."
  sha256: "..."
kraken2_standard:
  version: "k2_standard_20240605"
  url: "https://genome-idx.s3.amazonaws.com/kraken/k2_standard_20240605.tar.gz"
  sha256: "..."
```

`scripts/download_databases.sh` reads this file, downloads each database,
and verifies the checksum before extraction. On first install, the script
prints the actual hash of the downloaded file so you can paste it into
`databases.yaml` (placeholder values are checked in by default).

## Running the pipeline

### Locally

```bash
snakemake --cores 16 --use-conda
```

### On SLURM (recommended for production)

```bash
snakemake --profile profiles/slurm --use-conda
```

The SLURM profile (`profiles/slurm/config.yaml`) submits each rule
invocation as a separate job, with resources pulled from `config.yaml`
under `resources:`. Edit the profile to set your account, partition, etc.

This **replaces** the original `06_contig_amr.sh` array script. Snakemake
handles dependency resolution, retries, and partial-failure recovery
automatically.

### Useful commands

```bash
# Dry-run (show what would run, validate config)
snakemake --cores 1 --dry-run

# Run only one sample (for debugging)
snakemake --cores 4 --use-conda \
    results/06_contig_amr/PREVAIL_001_arg_contig_links.csv

# Force re-run of a specific rule
snakemake --cores 4 --use-conda --forcerun kraken2_classify

# Generate the run-provenance manifest only
snakemake --cores 1 results/06_contig_amr/run_manifest.tsv

# Render the DAG of jobs
snakemake --rulegraph | dot -Tpng > rulegraph.png
snakemake --dag       | dot -Tpng > dag.png
```

## Outputs

For each sample:

| File | Description |
|------|-------------|
| `{sample}_arg_contig_links.csv` | ARG hits joined to contig taxonomy (final per-sample deliverable) |
| `{sample}_contig_kraken.report` | Kraken2 taxonomic distribution of all assembled contigs |

Plus cohort-level:

| File | Description |
|------|-------------|
| `all_contig_arg_links.csv` | Concatenated linkage table across all samples |
| `run_manifest.tsv` | Reproducibility provenance: git commit, DB SHAs, tool versions, run date |

### Linkage table columns

| Column | Type | Description |
|--------|------|-------------|
| `sample_id` | string | Sample identifier |
| `contig_id` | string | MEGAHIT contig (e.g., `k141_12345`) |
| `arg_accession` | string | MEGARes accession (e.g., `MEG_1234`) |
| `arg_drug_class` | string | Antibiotic class (e.g., `Tetracyclines`) |
| `arg_mechanism` | string | Resistance mechanism |
| `arg_group` | string | Gene group (e.g., `TETM`) |
| `arg_gene_name` | string | Specific gene name |
| `pident` | float | Percent identity of BLAST alignment |
| `alignment_length` | int | Length of BLAST alignment (bp) |
| `qcovs` | float | Query coverage (%) |
| `evalue` | float | BLAST E-value |
| `bitscore` | float | BLAST bit score |
| `classified` | string | Kraken2 flag (`C` = classified, `U` = unclassified) |
| `taxid` | string | NCBI taxonomy ID |
| `taxonomy` | string | Taxonomic name (species/genus level) |

## Reproducibility

This pipeline is **designed** for one-button reproducibility. Current verification
status is tracked in [VERIFICATION.md](VERIFICATION.md) — please consult it
before relying on any specific claim below.

The reproducibility scaffolding consists of:

1. **Pinned tool versions** — every conda env in `envs/` lists exact
   versions (or minimum versions where the upstream is in flux); per-rule
   envs are auto-installed by Snakemake (`--use-conda`).
2. **Pinned database versions** — `config/databases.yaml` records URL +
   SHA256 + release date for every reference DB. `scripts/download_databases.sh`
   verifies hashes; mismatches abort. (Hashes are placeholders until first
   download — see [VERIFICATION.md](VERIFICATION.md).)
3. **Run-provenance manifest** — every successful pipeline run writes
   `run_manifest.tsv` capturing the git commit, the SHAs of the actual
   database files used, and the run date. This file is the single
   ground-truth record of what produced a given output set.
4. **Containerized environment** — Apptainer SIF and Docker images bundle
   the entire stack. The same SIF runs on any HPC; the same Docker image
   runs on any laptop.
5. **Deterministic test data** — `tests/build_test_data.py` produces
   byte-identical synthetic FASTQ + databases on every run (gzip mtime
   pinned to 0, fixed PRNG seed). Hashes are checked in
   `tests/test_data.sha256`.
6. **Continuous integration** — every push runs the full smoke test
   inside the conda environment described by `envs/environment.yml`.
   When the CI badge above is green, the latest commit produces the
   expected outputs from synthetic input.

### What's verified at v1.0.0 release

The Python linker (`workflow/scripts/link_args.py`) is unit-tested by
`tests/test_linker_logic.py`, which constructs realistic BLAST and Kraken2
outputs and confirms correct joining behavior including edge cases (empty
input, unclassified contigs).

The full Snakemake DAG **must be validated by CI** before any
reproducibility claim involving MEGAHIT, BLAST, or Kraken2 is substantiated.
See [VERIFICATION.md](VERIFICATION.md) for the complete tested-vs-untested
matrix and the iteration plan to reach green CI.

### Reproducing the published runs

To exactly reproduce the results reported in the PREVAIL dissertation:

```bash
# 1. Check out the release tag
git clone https://github.com/yourusername/contig-arg-linkage.git
cd contig-arg-linkage
git checkout v1.0.0

# 2. Install pinned databases
bash scripts/download_databases.sh all

# 3. Verify checksums match those in our run_manifest.tsv
sha256sum databases/megares/megares_database_v3.00.fasta
sha256sum databases/kraken2_standard/hash.k2d
# (compare against values in the run_manifest.tsv shipped with the paper)

# 4. Run
snakemake --profile profiles/slurm --use-conda
```

## Why this design

- **Snakemake over hand-rolled SLURM array** — automatic dependency
  resolution, partial-failure recovery, no per-sample bookkeeping.
- **Per-rule conda envs** — minimum-viable environments per tool keep
  rebuilds fast; `--use-conda` provides hermetic isolation without root.
- **MEGARes as BLAST query (not subject)** — one query per ARG finds all
  contigs carrying it in one pass; downstream join by contig ID is then
  trivial. Detection sensitivity is identical because BLAST is
  symmetric on local alignment.
- **`--memory-mapping` for Kraken2** — fits Kraken2 Standard (78 GB) on
  ordinary 48 GB compute nodes. Trades ~10x classification speed for the
  ability to avoid expensive high-memory partitions.

## Comparison with MGS2AMR

| Aspect | This pipeline | MGS2AMR |
|--------|---------------|---------|
| Assembly strategy | Full metagenome (MEGAHIT) | ARG-seeded (MetaCherchant) |
| ARG detection | BLASTn MEGARes vs contigs | Seed-based assembly around known ARGs |
| Taxonomic assignment | Kraken2 on contigs | BLASTn against NCBI prokaryotic genomes |
| Linkage evidence | Physical co-localization | GFA path scoring |
| RAM per sample | 48 GB | 200 GB |
| Time per sample | ~2 hours | ~20 minutes |

The two approaches are complementary — concordance between them
strengthens confidence in ARG–pathogen associations.

## Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| `OOM kill` on Kraken2 | DB loaded into RAM (no `--memory-mapping`) | Set `kraken2.memory_mapping: true` in `config.yaml` |
| `MEGAHIT: output dir exists` | Previous failed run left scratch files | `rm -rf scratch/06_contig_amr/{sample}` and rerun |
| `FileNotFoundError: ktaxonomy.tsv` | DB extracted but taxonomy lookup missing | Check that `kraken2_standard/ktaxonomy.tsv` exists; if not, the linker falls back to `taxid:NNNN` labels |
| `conda: command not found` in SLURM | Login shell hooks not loaded in batch jobs | Use `--use-conda` and let Snakemake activate envs explicitly |
| `Heredoc / SLURM script corruption` | Pasting multi-line strings into a terminal | Don't — edit scripts in a text editor or via `cat > script.sh <<'EOF'` |

## Citation

If you use this pipeline, please cite (citation file: [`CITATION.cff`](CITATION.cff)):

> Bakare AA. Contig-Based ARG–Pathogen Linkage Pipeline (v1.0.0). Zenodo.
> https://doi.org/10.5281/zenodo.PLACEHOLDER

Plus the underlying tools:

- **MEGAHIT** — Li D et al. *Bioinformatics*. 2015;31(10):1674–1676.
- **BLAST+** — Camacho C et al. *BMC Bioinformatics*. 2009;10:421.
- **Kraken2** — Wood DE, Lu J, Langmead B. *Genome Biology*. 2019;20:257.
- **MEGARes** — Doster E et al. *Nucleic Acids Research*. 2020;48(D1):D561–D569.
- **Snakemake** — Mölder F et al. *F1000Research*. 2021;10:33.

## License

MIT — see [LICENSE](LICENSE).

## Contact

Akeem A. Bakare, DVM, MPH
Department of Environmental and Public Health Sciences
University of Cincinnati

Issues and pull requests: see [CONTRIBUTING.md](CONTRIBUTING.md).
