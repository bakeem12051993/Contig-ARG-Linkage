# Verification Status

This document tracks what has and has not been tested for v1.0.0.
Reproducibility is a property of *verified* behavior; unverified claims
belong here, not in the README.

## ✅ Verified locally (Python-only, no bioinformatics tools required)

| Item | How |
|------|-----|
| `tests/build_test_data.py` runs without error | Direct execution |
| Test data is byte-deterministic across runs | Two runs → identical SHA256s in `tests/test_data.sha256` |
| Synthetic ARG sequences are valid DNA (ACGT only, start with ATG) | Programmatic check |
| `link_args.py` parses MEGARes pipe-delimited headers correctly | `tests/test_linker_logic.py` |
| `link_args.py` joins BLAST hits to Kraken2 taxonomy by contig ID | `tests/test_linker_logic.py` |
| `link_args.py` produces correct CSV schema | `tests/test_linker_logic.py` |
| `link_args.py` handles empty BLAST input (header-only CSV) | `tests/test_linker_logic.py` |
| `link_args.py` handles unclassified contigs (`U` flag, fallback taxonomy) | `tests/test_linker_logic.py` |
| All YAML config files parse | PyYAML `safe_load` |
| `.zenodo.json` is valid JSON | `json.load` |
| Production and test configs satisfy required-key constraints | Manual schema walk |
| All bash scripts pass `bash -n` | Direct check |
| All Python files compile (`py_compile`) | Direct check |
| No unused imports in Python files | Manual `grep` audit |

## ⚠ Verified by structure / convention only — needs first-run validation

| Item | Risk | How to verify |
|------|------|---------------|
| Snakemake `script:` directive correctly dispatches `link_args.py` | Medium — `if "snakemake" in globals():` is the canonical pattern but Snakemake's exec mechanism varies | Run `snakemake --cores 1 results/.../sample_X_arg_contig_links.csv` against real data |
| `snakemake-executor-plugin-slurm` minimum version pin | Low — pinned to `>=0.4` rather than exact | Check bioconda for currently available versions; pin exact for published runs |
| SLURM profile YAML format for Snakemake 8.10.7 | Medium — format has churned across 8.x point releases | `snakemake --profile profiles/slurm --dry-run` on cluster |
| Apptainer/Docker images build | Medium — multi-stage micromamba builds occasionally break on env conflicts | `apptainer build` / `docker build` |
| Per-rule conda envs install successfully via Snakemake `--use-conda` | Low — env files are minimal and tools are well-known | First `snakemake --use-conda` invocation |
| `pulp>=2.7,<3` constraint | Low — Snakemake's solver dependency, well-maintained | Install env |

## ❌ NOT verified — must be confirmed before public release

| Item | Why | Action required |
|------|-----|-----------------|
| **MEGARes download URL** in `config/databases.yaml` | I asserted `https://www.meglab.org/downloads/megares_v3.00/megares_database_v3.00.fasta` from memory; not checked | Visit URL in browser; update if redirected |
| **MEGARes SHA256** | Placeholder string | First `download_databases.sh` run prints actual hash; paste back into config |
| **Kraken2 build name `k2_standard_20240605`** | Date is plausible but unverified | Browse https://benlangmead.github.io/aws-indexes/k2 and pick a specific build |
| **Kraken2 SHA256** | Placeholder | Same as MEGARes |
| **Full pipeline smoke test (Snakemake + MEGAHIT + BLAST + Kraken2)** | None of these tools are available in the local environment | Push to GitHub and let CI run; or run locally with conda installed |
| **Kraken2 mini-DB build from synthetic taxonomy files** | `kraken2-build --build` is finicky about names.dmp/nodes.dmp formatting; I synthesized these from spec without testing | First smoke test run will reveal any format issues |
| **MEGAHIT assembling synthetic 30 kb random sequences** | MEGAHIT's `meta-sensitive` preset is calibrated for real metagenomes; behavior on small synthetic genomes unknown | Smoke test will reveal; may need to tune `min_contig_len` |
| **`snakefmt --check`** passes on the Snakefile | Tool not installed locally | Run in CI |
| **`shellcheck`** passes on shell scripts | Tool not installed locally | Run in CI; current scripts use `set -euo pipefail` and quoted variables |
| **`ruff check`** passes on Python files | Tool not installed locally; obvious unused imports manually removed | Run in CI |

## How to actually validate this on your end

The CI workflow in `.github/workflows/ci.yml` is designed to run all of these
checks at once. The path forward is:

1. Push the repository to GitHub.
2. The first CI run will fail. That's expected. Read the logs and fix.
3. Likely failure points (in order of probability):
   - Kraken2 mini-DB build format issues (taxonomy files)
   - Snakemake plugin version not found on bioconda → need to pin a real version
   - `snakefmt --check` complaining about formatting → run `snakefmt workflow/` and commit
   - `ruff check` flagging issues → run `ruff check --fix` and commit
4. Iterate until green. Expect 2–4 rounds.
5. Only after CI is green should the README's reproducibility claims be considered substantiated.

## What the smoke test asserts when it does run

When `tests/run_smoke_test.sh` succeeds, it confirms:

- All four tools (MEGAHIT, BLAST, Kraken2, the Python linker) execute without error
- The DAG resolves correctly (rules run in dependency order)
- The synthetic ARGs (CTX-M, FOSA, VANA) appear in the output CSV
- Output file paths and schemas match what the README documents
- Conda env activation works under `--use-conda`

It does NOT prove:

- The pipeline gives biologically correct results on real metagenomes (use real positive controls for that)
- Performance characteristics (use a profiling run on a representative sample)
- Behavior under cluster scheduling (use a small SLURM test job)

## How to update this document

When you verify something on the ⚠ or ❌ list, move it to ✅ with a date
and a short description of how. The git history of this file is part of
the reproducibility record.
