#!/usr/bin/env bash
# =============================================================================
# Snakemake job-status checker for SLURM.
#
# Snakemake calls this with a SLURM job id and expects "running", "success",
# or "failed" on stdout. The default sacct query handles array jobs, jobs
# that have rolled out of the active queue, and pending → running transitions.
#
# Reference: https://snakemake.readthedocs.io/en/stable/executing/cluster.html
# =============================================================================
set -euo pipefail

jobid="${1:?usage: $0 <slurm-job-id>}"

# Try sacct first (works for completed and recent jobs)
status=$(sacct -j "${jobid}" --format=State --noheader --parsable2 2>/dev/null \
         | head -n 1 \
         | awk '{print $1}')

# Fall back to squeue if sacct returns nothing (very freshly submitted jobs)
if [[ -z "${status}" ]]; then
    status=$(squeue -j "${jobid}" --noheader --format=%T 2>/dev/null \
             | head -n 1)
fi

case "${status}" in
    BOOT_FAIL|CANCELLED*|DEADLINE|FAILED|NODE_FAIL|OUT_OF_MEMORY|PREEMPTED|TIMEOUT)
        echo "failed"
        ;;
    COMPLETED)
        echo "success"
        ;;
    PENDING|RUNNING|REQUEUED|RESIZING|SUSPENDED|CONFIGURING|COMPLETING|"")
        echo "running"
        ;;
    *)
        # Unknown status: treat as running so Snakemake checks again
        echo "running"
        ;;
esac
