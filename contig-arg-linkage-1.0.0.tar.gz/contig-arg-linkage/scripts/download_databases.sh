#!/usr/bin/env bash
# =============================================================================
# Download and verify reference databases for contig-arg-linkage.
#
# Reads config/databases.yaml for URLs and SHA256 checksums. Downloads each
# database, verifies the checksum, and extracts to the configured location.
#
# A SHA256 of "PLACEHOLDER_REPLACE_AFTER_FIRST_DOWNLOAD" causes the script
# to compute and print the actual hash so you can paste it back into
# databases.yaml on first install. After that, mismatches abort.
#
# Usage:
#   bash scripts/download_databases.sh [megares|kraken2_standard|all]
# =============================================================================
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DB_CONFIG="${REPO_ROOT}/config/databases.yaml"
TARGET="${1:-all}"

# -----------------------------------------------------------------------------
# Tiny YAML reader (avoids a Python dependency for the install step).
# Reads `key:` blocks at indent 0 and `  field: value` at indent 2.
# -----------------------------------------------------------------------------
yaml_get() {
    local block="$1" field="$2"
    awk -v block="${block}:" -v field="${field}:" '
        $0 ~ "^" block "$" { in_block=1; next }
        /^[A-Za-z_]/ && !/^# / { in_block=0 }
        in_block && $1 == field {
            sub("^[[:space:]]*" field "[[:space:]]*", "")
            gsub(/^["'\'']|["'\'']$/, "")
            print
            exit
        }
    ' "${DB_CONFIG}"
}

verify_or_print() {
    local path="$1" expected="$2" name="$3"
    local actual
    actual=$(sha256sum "${path}" | cut -d' ' -f1)
    if [[ "${expected}" == "PLACEHOLDER_REPLACE_AFTER_FIRST_DOWNLOAD" ]]; then
        echo
        echo "  First-time install: paste this SHA256 into config/databases.yaml"
        echo "  under '${name}.sha256':"
        echo
        echo "    sha256: \"${actual}\""
        echo
    elif [[ "${expected}" != "${actual}" ]]; then
        echo "ERROR: SHA256 mismatch for ${name}"
        echo "  expected: ${expected}"
        echo "  actual:   ${actual}"
        echo "  file:     ${path}"
        echo
        echo "If the upstream database was legitimately updated, update"
        echo "databases.yaml and bump CHANGELOG.md."
        exit 1
    else
        echo "  SHA256 verified: ${actual}"
    fi
}

# -----------------------------------------------------------------------------
# MEGARes
# -----------------------------------------------------------------------------
download_megares() {
    local version url sha256 install_path
    version=$(yaml_get megares version)
    url=$(yaml_get megares url)
    sha256=$(yaml_get megares sha256)
    install_path=$(yaml_get megares install_path)

    echo "==> MEGARes ${version}"
    echo "    URL:     ${url}"
    echo "    Target:  ${install_path}"

    if [[ -f "${REPO_ROOT}/${install_path}" ]]; then
        echo "    Already present, verifying..."
    else
        mkdir -p "$(dirname "${REPO_ROOT}/${install_path}")"
        echo "    Downloading..."
        wget --quiet --show-progress -O "${REPO_ROOT}/${install_path}" "${url}"
    fi
    verify_or_print "${REPO_ROOT}/${install_path}" "${sha256}" "megares"
}

# -----------------------------------------------------------------------------
# Kraken2 Standard
# -----------------------------------------------------------------------------
download_kraken2() {
    local version url sha256 install_path archive
    version=$(yaml_get kraken2_standard version)
    url=$(yaml_get kraken2_standard url)
    sha256=$(yaml_get kraken2_standard sha256)
    install_path=$(yaml_get kraken2_standard install_path)
    archive="/tmp/${version}.tar.gz"

    echo "==> Kraken2 Standard ${version}  (~78 GB compressed)"
    echo "    URL:     ${url}"
    echo "    Target:  ${install_path}"

    # Skip download if DB already extracted and looks complete
    if [[ -f "${REPO_ROOT}/${install_path}/hash.k2d" ]] \
       && [[ -f "${REPO_ROOT}/${install_path}/opts.k2d" ]] \
       && [[ -f "${REPO_ROOT}/${install_path}/taxo.k2d" ]]; then
        echo "    Already extracted, skipping download"
        return 0
    fi

    if [[ ! -f "${archive}" ]]; then
        echo "    Downloading (this will take a while)..."
        wget --show-progress -O "${archive}" "${url}"
    fi
    verify_or_print "${archive}" "${sha256}" "kraken2_standard"

    mkdir -p "${REPO_ROOT}/${install_path}"
    echo "    Extracting..."
    tar -xzf "${archive}" -C "${REPO_ROOT}/${install_path}"
    rm -f "${archive}"

    # ktaxonomy.tsv ships in the Ben Langmead pre-built archives. Verify.
    if [[ ! -f "${REPO_ROOT}/${install_path}/ktaxonomy.tsv" ]]; then
        echo "WARN: ${install_path}/ktaxonomy.tsv not found in extracted DB."
        echo "      The pipeline will fall back to taxid-only labels."
    fi
}

# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
case "${TARGET}" in
    megares)          download_megares ;;
    kraken2_standard) download_kraken2 ;;
    all)              download_megares; download_kraken2 ;;
    *)
        echo "usage: $0 [megares|kraken2_standard|all]"
        exit 1
        ;;
esac

echo
echo "Done. Verify config/config.yaml points at the installed databases."
