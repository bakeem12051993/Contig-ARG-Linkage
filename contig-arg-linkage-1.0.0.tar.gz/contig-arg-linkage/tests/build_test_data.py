#!/usr/bin/env python3
"""
Build a fully self-contained, deterministic test dataset for the
contig-arg-linkage pipeline.

Generates:
    tests/data/genomes/
        genome_1.fasta              (synthetic E. coli-like + CTX-M)
        genome_2.fasta              (synthetic K. pneumoniae-like + fosA)
        genome_3.fasta              (synthetic C. difficile-like + vanA)
    tests/data/reads/
        sample_test_R1_decontam.fastq.gz
        sample_test_R2_decontam.fastq.gz
    tests/data/megares_mini.fasta   (3 ARGs in MEGARes header format)
    tests/data/kraken2_mini/        (minimal Kraken2-compatible DB inputs)
        library/added.fna
        taxonomy/names.dmp
        taxonomy/nodes.dmp
        seqid2taxid.map

The Kraken2 DB itself is built at test time via:
    kraken2-build --build --db tests/data/kraken2_mini

Everything is deterministic: re-running this script produces byte-identical
output.
"""

from __future__ import annotations

import argparse
import gzip
import io
import random
import sys
from pathlib import Path

# -----------------------------------------------------------------------------
# Deterministic source: a fixed PRNG seed yields the same genomes/reads every
# time. Do NOT change without bumping the test version in CHANGELOG.
# -----------------------------------------------------------------------------
SEED = 20260201

# Synthetic ARG sequences. These are FAKE for testing only -- not real
# resistance genes. Length and naming match MEGARes v3.0 conventions.
ARG_SEQUENCES = {
    "MEG_TEST_001|Drugs|betalactams|Class_A_betalactamases|CTX-M|blaCTX-M-15": (
        "ATGGTTAAAAAATCACTGCGCCAGTTCACCCTGATGGCAACGGCAACCGTCACGCTGTTGTTAGGAAGTGTG"
        "CCGCTGTATGCGCAAACGGCGGACGTACAGCAAAAACTTGCCGAATTAGAGCGGCAGTCGGGAGGCAGACTG"
        "GGTGTGGCATTGATTAACACAGCAGATAATTCGCAAATACTTTATCGTGCTGATGAGCGCTTTGCGATGTGC"
    ),
    "MEG_TEST_002|Drugs|fosfomycin|Fosfomycin_target_redirection|FOSA|fosA": (
        "ATGTTAACAGGAATTAACCATGTGACGCTGGCGGTAAGCGATTTAGAGCGCTCAATAAGTTTTTACGAGAAA"
        "ATTTTAGGCTTAAAAGAACTGCAGGCGGTTACAGCAATTACAGGCGCGAACATCCACGGCATTACGGGCGTG"
        "CTGCAATTAACTAACAATGTGTTTATCGAACTGGAACAGGGGCAGGAGCATATGAAACGCATGCATCTGCAT"
    ),
    "MEG_TEST_003|Drugs|glycopeptides|Vancomycin_resistance_protein|VANA|vanA": (
        "ATGAATAGAATAAAAGTTGCAATACTGTTCGGGGGCTGCTCAGAGGAGCATGACGTATCGGTAAAATCAGCA"
        "ATAGAGATTGCAGCAAATATTAATAAAGAAAAATATGAGCCATTAGTAATAGGTATTACAAAGAGTGGCGTC"
        "TGGAAAATGTGTGAAAAACCATGTACTGAATTTGAAAATGATGCCAGCGCAACAATCCTTGCCCTACATGGT"
    ),
}

# Synthetic "host" genomes (random nt sequences that look organism-like).
# Each gets one ARG inserted.
GENOME_SPECS = [
    {
        "name": "genome_1",
        "taxid": 562,           # NCBI taxid for E. coli (we keep real taxids
        "taxon": "Escherichia coli (test stand-in)",
        "rank": "species",
        "parent_taxid": 561,    # Escherichia
        "size_bp": 30000,
        "arg_key": "MEG_TEST_001|Drugs|betalactams|Class_A_betalactamases|CTX-M|blaCTX-M-15",
    },
    {
        "name": "genome_2",
        "taxid": 573,           # K. pneumoniae
        "taxon": "Klebsiella pneumoniae (test stand-in)",
        "rank": "species",
        "parent_taxid": 570,    # Klebsiella
        "size_bp": 30000,
        "arg_key": "MEG_TEST_002|Drugs|fosfomycin|Fosfomycin_target_redirection|FOSA|fosA",
    },
    {
        "name": "genome_3",
        "taxid": 1496,          # C. difficile
        "taxon": "Clostridioides difficile (test stand-in)",
        "rank": "species",
        "parent_taxid": 1870884,  # Clostridioides
        "size_bp": 30000,
        "arg_key": "MEG_TEST_003|Drugs|glycopeptides|Vancomycin_resistance_protein|VANA|vanA",
    },
]

# Read simulation parameters
READ_LENGTH = 150
INSERT_SIZE = 350
COVERAGE = 30                  # ~30x is plenty for MEGAHIT to assemble


# -----------------------------------------------------------------------------
# Sequence generation
# -----------------------------------------------------------------------------
def random_nt_sequence(rng: random.Random, length: int) -> str:
    """GC-content ~50% random nucleotide sequence (deterministic given rng)."""
    return "".join(rng.choices("ACGT", k=length))


def write_fasta(path: Path, header: str, seq: str, line_width: int = 70) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        f.write(f">{header}\n")
        for i in range(0, len(seq), line_width):
            f.write(seq[i : i + line_width] + "\n")


def reverse_complement(seq: str) -> str:
    comp = str.maketrans("ACGT", "TGCA")
    return seq.translate(comp)[::-1]


def simulate_reads(
    genome: str,
    rng: random.Random,
    n_reads: int,
    read_len: int,
    insert_size: int,
) -> list[tuple[str, str]]:
    """Simulate paired-end reads (no errors -- this is a pipeline smoke test).

    Returns list of (r1_seq, r2_seq) tuples. R2 is reverse-complement of the
    second mate, mimicking Illumina paired-end orientation.
    """
    reads = []
    max_start = len(genome) - insert_size - 1
    for _ in range(n_reads):
        start = rng.randrange(0, max_start)
        fragment = genome[start : start + insert_size]
        r1 = fragment[:read_len]
        r2 = reverse_complement(fragment[-read_len:])
        reads.append((r1, r2))
    return reads


def write_fastq_gz(path: Path, reads: list[str], read_id_prefix: str) -> None:
    """Write reads as gzipped FASTQ with dummy quality string (all 'I' = Q40).

    mtime=0 makes the gzip output byte-identical across runs (default behavior
    embeds the current time in the gzip header, which would break determinism).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    qual = "I" * READ_LENGTH
    with gzip.GzipFile(filename=str(path), mode="wb", mtime=0) as raw_f:
        text_f = io.TextIOWrapper(raw_f, encoding="utf-8")
        for i, seq in enumerate(reads):
            text_f.write(f"@{read_id_prefix}_{i}\n{seq}\n+\n{qual}\n")
        text_f.flush()
        text_f.detach()


# -----------------------------------------------------------------------------
# Kraken2 minimal DB scaffolding
# -----------------------------------------------------------------------------
def write_kraken2_inputs(out_dir: Path, genome_specs: list[dict]) -> None:
    """Lay out the input files Kraken2 expects for `kraken2-build --build`.

    Kraken2 needs:
      - <db>/library/<name>.fna  (sequences with kraken taxid headers)
      - <db>/taxonomy/names.dmp
      - <db>/taxonomy/nodes.dmp
      - <db>/seqid2taxid.map     (sequence_id -> taxid)
    """
    library_dir = out_dir / "library"
    taxonomy_dir = out_dir / "taxonomy"
    library_dir.mkdir(parents=True, exist_ok=True)
    taxonomy_dir.mkdir(parents=True, exist_ok=True)

    # ---- Combined library FASTA, one record per genome
    library_fa = library_dir / "added.fna"
    seqid2taxid = []
    with open(library_fa, "w") as f:
        for spec in genome_specs:
            seq_id = f"{spec['name']}|kraken:taxid|{spec['taxid']}"
            f.write(f">{seq_id} {spec['taxon']}\n")
            with open(out_dir.parent / "genomes" / f"{spec['name']}.fasta") as gf:
                # Skip the header, write the sequence
                next(gf)
                for line in gf:
                    f.write(line)
            seqid2taxid.append(f"{seq_id}\t{spec['taxid']}")

    (out_dir / "seqid2taxid.map").write_text("\n".join(seqid2taxid) + "\n")

    # ---- names.dmp: NCBI taxonomy names format
    # Format: tax_id\t|\tname_txt\t|\tunique_name\t|\tname_class\t|
    names_lines = [
        "1\t|\troot\t|\t\t|\tscientific name\t|",
        "131567\t|\tcellular organisms\t|\t\t|\tscientific name\t|",
        "2\t|\tBacteria\t|\t\t|\tscientific name\t|",
    ]
    # Add genus + species for each spec (parents must be present)
    parent_added = set()
    for spec in genome_specs:
        if spec["parent_taxid"] not in parent_added:
            names_lines.append(
                f"{spec['parent_taxid']}\t|\tParent_{spec['parent_taxid']}\t|\t\t|\tscientific name\t|"
            )
            parent_added.add(spec["parent_taxid"])
        names_lines.append(
            f"{spec['taxid']}\t|\t{spec['taxon']}\t|\t\t|\tscientific name\t|"
        )
    (taxonomy_dir / "names.dmp").write_text("\n".join(names_lines) + "\n")

    # ---- nodes.dmp: NCBI taxonomy hierarchy format
    # Format: tax_id\t|\tparent_tax_id\t|\trank\t|\t...embl_code...\t|... (13 fields)
    def node_line(tax_id, parent, rank):
        # Pad with empty fields per NCBI spec
        return (
            f"{tax_id}\t|\t{parent}\t|\t{rank}\t|\t\t|\t0\t|\t0\t|\t11\t|"
            f"\t1\t|\t0\t|\t0\t|\t0\t|\t0\t|\t\t|"
        )

    nodes_lines = [
        node_line(1, 1, "no rank"),
        node_line(131567, 1, "no rank"),
        node_line(2, 131567, "superkingdom"),
    ]
    parent_added = set()
    for spec in genome_specs:
        if spec["parent_taxid"] not in parent_added:
            nodes_lines.append(node_line(spec["parent_taxid"], 2, "genus"))
            parent_added.add(spec["parent_taxid"])
        nodes_lines.append(
            node_line(spec["taxid"], spec["parent_taxid"], spec["rank"])
        )
    (taxonomy_dir / "nodes.dmp").write_text("\n".join(nodes_lines) + "\n")


# -----------------------------------------------------------------------------
# MEGARes mini DB
# -----------------------------------------------------------------------------
def write_megares_mini(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        for header, seq in ARG_SEQUENCES.items():
            f.write(f">{header}\n")
            for i in range(0, len(seq), 70):
                f.write(seq[i : i + 70] + "\n")


# -----------------------------------------------------------------------------
# Driver
# -----------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--out-dir", type=Path, default=Path("tests/data"),
                   help="Output directory (default: tests/data)")
    args = p.parse_args()

    out = args.out_dir
    rng = random.Random(SEED)

    # ---- 1. Build synthetic genomes (random NT + inserted ARG) ----
    print(f"[test-data] Generating {len(GENOME_SPECS)} synthetic genomes...",
          file=sys.stderr)
    for spec in GENOME_SPECS:
        backbone = random_nt_sequence(rng, spec["size_bp"])
        arg_seq = ARG_SEQUENCES[spec["arg_key"]]
        # Insert ARG at the midpoint
        midpoint = len(backbone) // 2
        genome = backbone[:midpoint] + arg_seq + backbone[midpoint:]
        write_fasta(
            out / "genomes" / f"{spec['name']}.fasta",
            header=f"{spec['name']} | taxid:{spec['taxid']} | {spec['taxon']}",
            seq=genome,
        )
        print(f"  {spec['name']}: {len(genome):,} bp (ARG inserted at {midpoint})",
              file=sys.stderr)

    # ---- 2. Simulate paired-end reads ----
    print(f"[test-data] Simulating paired-end reads ({COVERAGE}x coverage)...",
          file=sys.stderr)
    all_r1, all_r2 = [], []
    for spec in GENOME_SPECS:
        with open(out / "genomes" / f"{spec['name']}.fasta") as f:
            next(f)  # skip header
            genome = "".join(line.strip() for line in f)
        n_reads = (COVERAGE * len(genome)) // (2 * READ_LENGTH)
        pairs = simulate_reads(genome, rng, n_reads, READ_LENGTH, INSERT_SIZE)
        for r1, r2 in pairs:
            all_r1.append(r1)
            all_r2.append(r2)
        print(f"  {spec['name']}: {n_reads:,} read pairs", file=sys.stderr)

    # Shuffle so reads from different genomes interleave (more realistic)
    indices = list(range(len(all_r1)))
    rng.shuffle(indices)
    all_r1 = [all_r1[i] for i in indices]
    all_r2 = [all_r2[i] for i in indices]

    write_fastq_gz(out / "reads" / "sample_test_R1_decontam.fastq.gz",
                   all_r1, "test_read")
    write_fastq_gz(out / "reads" / "sample_test_R2_decontam.fastq.gz",
                   all_r2, "test_read")
    print(f"  Total: {len(all_r1):,} read pairs", file=sys.stderr)

    # ---- 3. Mini MEGARes DB ----
    print("[test-data] Writing mini MEGARes FASTA...", file=sys.stderr)
    write_megares_mini(out / "megares_mini.fasta")

    # ---- 4. Kraken2 DB inputs (DB itself is built at smoke-test time) ----
    print("[test-data] Writing Kraken2 build inputs...", file=sys.stderr)
    write_kraken2_inputs(out / "kraken2_mini", GENOME_SPECS)

    print("[test-data] Done.", file=sys.stderr)


if __name__ == "__main__":
    main()
