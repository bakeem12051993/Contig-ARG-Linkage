#!/usr/bin/env python3
"""
Standalone test of link_args.py logic.

Constructs realistic BLAST + Kraken2 outputs by hand, runs the linker,
and verifies the joined CSV is correct.

This catches bugs in the linker itself even when we can't run the full
Snakemake DAG (e.g., when MEGAHIT/BLAST/Kraken2 aren't installed).
"""
import csv
import subprocess
import sys
import tempfile
from pathlib import Path

# Where the actual linker lives
SCRIPT = Path(__file__).resolve().parent.parent / "workflow/scripts/link_args.py"

# -----------------------------------------------------------------------------
# Synthetic BLAST output (outfmt 6 + qcovs).
# Three ARGs hit three different contigs.
# Format: qseqid sseqid pident length mismatch gapopen
#         qstart qend sstart send evalue bitscore qcovs
# -----------------------------------------------------------------------------
BLAST_HITS = [
    # CTX-M-15 hits contig from sample on k141_1
    ("MEG_TEST_001|Drugs|betalactams|Class_A_betalactamases|CTX-M|blaCTX-M-15",
     "k141_1", "98.50", "210", "3", "0",
     "1", "210", "14990", "15200", "1e-95", "365.5", "100.0"),
    # FOSA hits k141_2
    ("MEG_TEST_002|Drugs|fosfomycin|Fosfomycin_target_redirection|FOSA|fosA",
     "k141_2", "100.0", "210", "0", "0",
     "1", "210", "14995", "15205", "1e-105", "401.2", "100.0"),
    # VANA hits k141_3
    ("MEG_TEST_003|Drugs|glycopeptides|Vancomycin_resistance_protein|VANA|vanA",
     "k141_3", "97.20", "210", "5", "1",
     "1", "210", "15001", "15212", "1e-90", "350.1", "100.0"),
    # Edge case: a hit on a contig that Kraken2 left unclassified
    ("MEG_TEST_001|Drugs|betalactams|Class_A_betalactamases|CTX-M|blaCTX-M-15",
     "k141_99", "85.00", "180", "20", "2",
     "5", "184", "100", "280", "1e-50", "200.0", "85.7"),
]

# -----------------------------------------------------------------------------
# Synthetic Kraken2 per-contig output.
# Format: C/U  contig_id  taxid  length  LCA_mapping
# -----------------------------------------------------------------------------
KRAKEN_OUTPUT = [
    ("C", "k141_1",  "562",  "30216", "0:1 562:140 0:50"),   # E. coli
    ("C", "k141_2",  "573",  "30216", "0:5 573:135 0:50"),   # K. pneumoniae
    ("C", "k141_3",  "1496", "30216", "0:2 1496:138 0:50"),  # C. difficile
    ("U", "k141_99", "0",    "5000",  "0:50"),                # unclassified
    ("C", "k141_50", "511145", "8000", "511145:120"),         # bystander, no ARG
]

# -----------------------------------------------------------------------------
# Synthetic ktaxonomy.tsv (taxid → name)
# -----------------------------------------------------------------------------
TAXONOMY = [
    ("562",    "Escherichia coli"),
    ("573",    "Klebsiella pneumoniae"),
    ("1496",   "Clostridioides difficile"),
    ("511145", "Escherichia coli K-12"),
]


def write_tsv(path: Path, rows):
    with open(path, "w") as f:
        for row in rows:
            f.write("\t".join(row) + "\n")


def main():
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        blast_file = tmp / "arg_hits.txt"
        kraken_file = tmp / "contig_kraken.txt"
        ktax_file = tmp / "ktaxonomy.tsv"
        output_file = tmp / "links.csv"

        write_tsv(blast_file, BLAST_HITS)
        write_tsv(kraken_file, KRAKEN_OUTPUT)
        write_tsv(ktax_file, TAXONOMY)

        # Run the linker via its CLI entry point
        result = subprocess.run([
            sys.executable, str(SCRIPT),
            "--sample-id", "test_sample",
            "--blast", str(blast_file),
            "--kraken", str(kraken_file),
            "--ktax", str(ktax_file),
            "--output", str(output_file),
        ], capture_output=True, text=True)

        if result.returncode != 0:
            print("FAIL: linker exited non-zero", file=sys.stderr)
            print("stdout:", result.stdout, file=sys.stderr)
            print("stderr:", result.stderr, file=sys.stderr)
            sys.exit(1)

        # Read and validate output
        with open(output_file) as f:
            reader = csv.DictReader(f)
            rows = list(reader)

        # Assertions
        assert len(rows) == 4, f"Expected 4 rows, got {len(rows)}"

        # Build a lookup by ARG group + contig
        by_arg = {(r["arg_group"], r["contig_id"]): r for r in rows}

        # Check 1: CTX-M on k141_1 → E. coli (taxid 562, classified)
        ctx_ec = by_arg[("CTX-M", "k141_1")]
        assert ctx_ec["classified"] == "C", f"k141_1 should be classified, got {ctx_ec['classified']}"
        assert ctx_ec["taxid"] == "562", f"k141_1 taxid should be 562, got {ctx_ec['taxid']}"
        assert ctx_ec["taxonomy"] == "Escherichia coli", \
            f"k141_1 taxonomy lookup failed: got {ctx_ec['taxonomy']}"
        assert ctx_ec["arg_drug_class"] == "betalactams"
        assert ctx_ec["arg_gene_name"] == "blaCTX-M-15"
        assert float(ctx_ec["pident"]) == 98.50

        # Check 2: FOSA on k141_2 → K. pneumoniae
        fosa = by_arg[("FOSA", "k141_2")]
        assert fosa["taxonomy"] == "Klebsiella pneumoniae"
        assert fosa["arg_drug_class"] == "fosfomycin"

        # Check 3: VANA on k141_3 → C. difficile
        vana = by_arg[("VANA", "k141_3")]
        assert vana["taxonomy"] == "Clostridioides difficile"
        assert vana["arg_drug_class"] == "glycopeptides"

        # Check 4: CTX-M on k141_99 → unclassified
        ctx_unc = by_arg[("CTX-M", "k141_99")]
        assert ctx_unc["classified"] == "U", \
            f"k141_99 should be unclassified, got {ctx_unc['classified']}"
        assert ctx_unc["taxid"] == "0"
        # Taxid 0 isn't in our taxonomy lookup -> falls back to "taxid:0"
        # OR Kraken's "U" line in some configs gives no name; either is OK
        # so we just check the taxid is right

        # Check 5: bystander contig k141_50 (classified but no ARG hit)
        # should NOT appear in linkages
        bystander_keys = [k for k in by_arg if k[1] == "k141_50"]
        assert len(bystander_keys) == 0, "Contigs without ARG hits should be excluded"

        print(f"Linker test PASSED: {len(rows)} linkages produced, all assertions OK")
        print(f"  CTX-M     -> Escherichia coli       (98.50% identity)")
        print(f"  FOSA      -> Klebsiella pneumoniae  (100.0% identity)")
        print(f"  VANA      -> Clostridioides difficile (97.20% identity)")
        print(f"  CTX-M     -> unclassified            (k141_99 not in Kraken2 hits)")


if __name__ == "__main__":
    main()
