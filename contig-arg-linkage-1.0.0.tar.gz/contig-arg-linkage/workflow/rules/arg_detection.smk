# =============================================================================
# rules/arg_detection.smk -- BLASTn search for ARGs against per-sample contigs
# =============================================================================
#
# Direction note: We use MEGARes ARG sequences as the QUERY and the per-sample
# contigs as the DATABASE. This is unconventional vs. the more common
# `query=contigs, db=ARG_reference` direction. The reason is symmetric in
# terms of detection (BLAST is a Smith-Waterman-like local aligner) but our
# direction lets a single MEGARes query find ALL contigs carrying that ARG
# in one pass, which is convenient for the downstream link.
# =============================================================================

rule make_blast_db:
    """Build a BLAST nucleotide database from per-sample contigs."""
    input:
        contigs=str(TMP_DIR / "{sample}" / "final.contigs.fa"),
    output:
        # BLAST nucl DB consists of .nhr/.nin/.nsq (and friends for v5 format)
        db_marker=temp(str(TMP_DIR / "{sample}" / "blastdb.nhr")),
    params:
        prefix=lambda wc: str(TMP_DIR / wc.sample / "blastdb"),
    log:
        str(LOG_DIR / "blast" / "{sample}.makedb.log"),
    conda:
        "../envs/blast.yml"
    shell:
        r"""
        set -euo pipefail
        makeblastdb \
            -in {input.contigs} \
            -dbtype nucl \
            -out {params.prefix} \
            > {log} 2>&1
        """


rule blastn_arg:
    """
    Detect ARGs on contigs by BLASTn of MEGARes ARG sequences vs. contig DB.

    Output columns (outfmt 6 + qcovs):
        qseqid sseqid pident length mismatch gapopen
        qstart qend sstart send evalue bitscore qcovs
    """
    input:
        db_marker=str(TMP_DIR / "{sample}" / "blastdb.nhr"),
        megares=str(MEGARES_DB),
    output:
        hits=temp(str(TMP_DIR / "{sample}" / "arg_hits.txt")),
    params:
        db_prefix=lambda wc: str(TMP_DIR / wc.sample / "blastdb"),
        evalue=config["blast"]["evalue"],
        pident=config["blast"]["perc_identity"],
        max_targets=config["blast"]["max_target_seqs"],
    threads: config["resources"]["blast"]["threads"]
    resources:
        mem_mb=config["resources"]["blast"]["mem_mb"],
        runtime=config["resources"]["blast"]["runtime_min"],
    log:
        str(LOG_DIR / "blast" / "{sample}.blastn.log"),
    benchmark:
        str(LOG_DIR / "blast" / "{sample}.benchmark.tsv")
    conda:
        "../envs/blast.yml"
    shell:
        r"""
        set -euo pipefail
        blastn \
            -query {input.megares} \
            -db {params.db_prefix} \
            -out {output.hits} \
            -outfmt "6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send evalue bitscore qcovs" \
            -evalue {params.evalue} \
            -perc_identity {params.pident} \
            -max_target_seqs {params.max_targets} \
            -num_threads {threads} \
            2> {log}

        NHITS=$(wc -l < {output.hits})
        echo "Found ${{NHITS}} ARG hits" >> {log}
        """
