# =============================================================================
# rules/assembly.smk -- MEGAHIT metagenomic assembly
# =============================================================================

rule megahit_assembly:
    """
    Assemble host-removed paired-end reads into contigs using MEGAHIT.

    Notes:
      - --presets meta-sensitive uses k-mer list 21,33,55,77,99,121
      - Min contig length 500 bp matches downstream BLAST search efficiency
      - MEGAHIT REFUSES to write to an existing directory; we use a unique
        per-sample temp dir and rename on success.
      - Output is marked temp() so Snakemake auto-removes after downstream
        rules consume it (saves ~1 GB / sample).
    """
    input:
        r1=get_r1,
        r2=get_r2,
    output:
        contigs=temp(str(TMP_DIR / "{sample}" / "final.contigs.fa")),
    params:
        outdir=lambda wc: str(TMP_DIR / wc.sample),
        min_len=config["megahit"]["min_contig_len"],
        preset=config["megahit"]["preset"],
    threads: config["resources"]["megahit"]["threads"]
    resources:
        mem_mb=config["resources"]["megahit"]["mem_mb"],
        runtime=config["resources"]["megahit"]["runtime_min"],
    log:
        str(LOG_DIR / "megahit" / "{sample}.log"),
    benchmark:
        str(LOG_DIR / "megahit" / "{sample}.benchmark.tsv")
    conda:
        "../envs/megahit.yml"
    shell:
        r"""
        set -euo pipefail

        # MEGAHIT requires non-existent output dir
        WORK={params.outdir}_work
        rm -rf "$WORK"

        megahit \
            -1 {input.r1} \
            -2 {input.r2} \
            -o "$WORK" \
            --min-contig-len {params.min_len} \
            -t {threads} \
            --presets {params.preset} \
            > {log} 2>&1

        # Move final contigs to expected location, then clean intermediate files
        mkdir -p {params.outdir}
        mv "$WORK/final.contigs.fa" {output.contigs}
        rm -rf "$WORK"

        NCONTIGS=$(grep -c "^>" {output.contigs} || echo 0)
        echo "Assembled ${{NCONTIGS}} contigs >= {params.min_len} bp" >> {log}
        """
