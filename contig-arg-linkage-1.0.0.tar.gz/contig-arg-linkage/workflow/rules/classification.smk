# =============================================================================
# rules/classification.smk -- Kraken2 taxonomic classification of contigs
# =============================================================================

rule kraken2_classify:
    """
    Classify contigs taxonomically using Kraken2 against the Standard DB.

    Notes:
      - --memory-mapping reads the 78 GB DB via mmap instead of loading it
        into RAM. This trades ~10x slower classification for the ability to
        run on standard 48 GB nodes (vs. 80+ GB high-memory partitions).
      - The .report file is preserved (sample-level taxonomy summary), the
        .txt per-contig output is consumed by the linker rule and then
        deleted.
    """
    input:
        contigs=str(TMP_DIR / "{sample}" / "final.contigs.fa"),
    output:
        kraken_out=temp(str(TMP_DIR / "{sample}" / "contig_kraken.txt")),
        report=str(RESULTS_DIR / "{sample}_contig_kraken.report"),
    params:
        db=str(KRAKEN_DB),
        memory_mapping="--memory-mapping" if config["kraken2"]["memory_mapping"] else "",
        confidence=config["kraken2"]["confidence"],
    threads: config["resources"]["kraken2"]["threads"]
    resources:
        mem_mb=config["resources"]["kraken2"]["mem_mb"],
        runtime=config["resources"]["kraken2"]["runtime_min"],
    log:
        str(LOG_DIR / "kraken2" / "{sample}.log"),
    benchmark:
        str(LOG_DIR / "kraken2" / "{sample}.benchmark.tsv")
    conda:
        "../envs/kraken2.yml"
    shell:
        r"""
        set -euo pipefail
        kraken2 \
            --db {params.db} \
            --threads {threads} \
            {params.memory_mapping} \
            --confidence {params.confidence} \
            --output {output.kraken_out} \
            --report {output.report} \
            {input.contigs} \
            2> {log}
        """
