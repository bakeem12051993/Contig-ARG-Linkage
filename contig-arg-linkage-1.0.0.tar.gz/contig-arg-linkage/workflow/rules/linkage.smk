# =============================================================================
# rules/linkage.smk -- Join ARG BLAST hits to Kraken2 taxonomy by contig
# =============================================================================

rule link_args:
    """Link ARG BLAST hits to Kraken2 contig classifications by contig ID."""
    input:
        blast=str(TMP_DIR / "{sample}" / "arg_hits.txt"),
        kraken=str(TMP_DIR / "{sample}" / "contig_kraken.txt"),
        ktax=str(KRAKEN_TAX),
    output:
        links=str(RESULTS_DIR / "{sample}_arg_contig_links.csv"),
    params:
        sample_id=lambda wc: wc.sample,
    log:
        str(LOG_DIR / "link_args" / "{sample}.log"),
    conda:
        "../envs/python.yml"
    script:
        "../scripts/link_args.py"


rule aggregate_links:
    """Concatenate per-sample linkage tables into one cohort-level table."""
    input:
        links=expand(str(RESULTS_DIR / "{sample}_arg_contig_links.csv"),
                     sample=SAMPLES),
    output:
        combined=str(RESULTS_DIR / "all_contig_arg_links.csv"),
    params:
        n_samples=len(SAMPLES),
    log:
        str(LOG_DIR / "aggregate_links.log"),
    conda:
        "../envs/python.yml"
    shell:
        r"""
        set -euo pipefail
        # Header from first file, then tail -n +2 from all files
        head -1 {input.links[0]} > {output.combined}
        for f in {input.links}; do
            tail -n +2 "$f" >> {output.combined}
        done
        N=$(($(wc -l < {output.combined}) - 1))
        echo "Aggregated ${{N}} ARG-contig linkages from {params.n_samples} samples" > {log}
        """
