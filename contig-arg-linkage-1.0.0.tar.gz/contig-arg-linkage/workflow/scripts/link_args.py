#!/usr/bin/env python3
"""
Link ARG BLAST hits to Kraken2 taxonomic classifications by contig ID.

Produces a CSV joining ARG identity on a contig with that contig's taxonomic
classification, providing direct evidence of which organisms carry which
resistance genes.

This script is invoked by Snakemake's `script:` directive, which provides a
`snakemake` object with `input`, `output`, `params`, `log`, and `wildcards`
attributes. When run standalone, it falls back to argparse.
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path
from typing import Iterator


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------
def parse_megares_header(header: str) -> dict[str, str]:
    """Parse a MEGARes v3.0 FASTA header.

    MEGARes headers follow the pipe-delimited format:
        MEG_####|Drugs|Drug_class|Mechanism|Group|Gene_name

    Returns a dict with keys: accession, drug_class, mechanism, group, gene_name.
    Falls back to the raw header in `accession` and "Unknown" elsewhere if the
    format does not match.
    """
    parts = header.split("|")
    if len(parts) >= 6:
        return {
            "accession": parts[0],
            "drug_class": parts[2],
            "mechanism": parts[3],
            "group": parts[4],
            "gene_name": parts[5],
        }
    return {
        "accession": header,
        "drug_class": "Unknown",
        "mechanism": "Unknown",
        "group": "Unknown",
        "gene_name": "Unknown",
    }


def parse_kraken2_output(kraken_file: Path) -> dict[str, tuple[str, str]]:
    """Parse Kraken2 per-sequence output → {contig_id: (classified_flag, taxid)}.

    Kraken2 output columns:
        C/U  sequence_id  taxid  length  LCA_mapping
    """
    contig_tax: dict[str, tuple[str, str]] = {}
    with open(kraken_file) as f:
        for line in f:
            fields = line.rstrip("\n").split("\t")
            if len(fields) >= 3:
                classified, contig_id, taxid = fields[0], fields[1], fields[2]
                contig_tax[contig_id] = (classified, taxid)
    return contig_tax


def load_taxonomy(ktax_file: Path) -> dict[str, str]:
    """Load Kraken2 taxonomy lookup (taxid → name)."""
    tax_map: dict[str, str] = {}
    if not ktax_file.exists():
        return tax_map
    with open(ktax_file) as f:
        for row in csv.reader(f, delimiter="\t"):
            if len(row) >= 2:
                tax_map[row[0]] = row[1].strip()
    return tax_map


def parse_blast_hits(blast_file: Path) -> Iterator[dict[str, object]]:
    """Yield BLAST outfmt-6 (+qcovs) hits one at a time.

    13 columns expected:
        qseqid sseqid pident length mismatch gapopen
        qstart qend sstart send evalue bitscore qcovs
    """
    with open(blast_file) as f:
        for line in f:
            fields = line.rstrip("\n").split("\t")
            if len(fields) < 13:
                continue
            arg_info = parse_megares_header(fields[0])
            yield {
                "arg_accession": arg_info["accession"],
                "arg_drug_class": arg_info["drug_class"],
                "arg_mechanism": arg_info["mechanism"],
                "arg_group": arg_info["group"],
                "arg_gene_name": arg_info["gene_name"],
                "contig_id": fields[1],
                "pident": float(fields[2]),
                "alignment_length": int(fields[3]),
                "qstart": int(fields[6]),
                "qend": int(fields[7]),
                "sstart": int(fields[8]),
                "send": int(fields[9]),
                "evalue": float(fields[10]),
                "bitscore": float(fields[11]),
                "qcovs": float(fields[12]),
            }


# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------
OUTPUT_HEADER = [
    "sample_id", "contig_id",
    "arg_accession", "arg_drug_class", "arg_mechanism",
    "arg_group", "arg_gene_name",
    "pident", "alignment_length", "qcovs", "evalue", "bitscore",
    "classified", "taxid", "taxonomy",
]


def link(
    sample_id: str,
    blast_file: Path,
    kraken_file: Path,
    ktax_file: Path,
    output_file: Path,
    log_handle=sys.stderr,
) -> tuple[int, int]:
    """Join BLAST ARG hits with Kraken2 taxonomy. Returns (n_classified, n_unclassified)."""
    output_file.parent.mkdir(parents=True, exist_ok=True)

    # Empty-input case: write header-only CSV and exit
    if not blast_file.exists() or blast_file.stat().st_size == 0:
        print(f"  No BLAST hits for {sample_id}; writing empty output",
              file=log_handle)
        with open(output_file, "w", newline="") as f:
            csv.writer(f).writerow(OUTPUT_HEADER)
        return (0, 0)

    if not kraken_file.exists():
        raise FileNotFoundError(f"Kraken2 output missing: {kraken_file}")

    print(f"  Parsing Kraken2 output: {kraken_file}", file=log_handle)
    contig_tax = parse_kraken2_output(kraken_file)
    print(f"    {len(contig_tax)} contigs classified", file=log_handle)

    print(f"  Loading taxonomy lookup: {ktax_file}", file=log_handle)
    tax_map = load_taxonomy(ktax_file)
    if not tax_map:
        print("    [warn] taxonomy file empty/missing; using taxid: prefix",
              file=log_handle)

    n_classified = 0
    n_unclassified = 0

    with open(output_file, "w", newline="") as out_f:
        writer = csv.writer(out_f)
        writer.writerow(OUTPUT_HEADER)

        for hit in parse_blast_hits(blast_file):
            contig_id = hit["contig_id"]

            if contig_id in contig_tax:
                classified, taxid = contig_tax[contig_id]
                taxonomy = tax_map.get(taxid, f"taxid:{taxid}")
                if classified == "C":
                    n_classified += 1
                else:
                    n_unclassified += 1
            else:
                # Contig not in Kraken2 output (shouldn't happen, but defensive)
                classified, taxid, taxonomy = "U", "0", "unclassified"
                n_unclassified += 1

            writer.writerow([
                sample_id, contig_id,
                hit["arg_accession"], hit["arg_drug_class"], hit["arg_mechanism"],
                hit["arg_group"], hit["arg_gene_name"],
                hit["pident"], hit["alignment_length"], hit["qcovs"],
                hit["evalue"], hit["bitscore"],
                classified, taxid, taxonomy,
            ])

    return (n_classified, n_unclassified)


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------
def _from_snakemake(sm) -> None:
    """Invocation path: Snakemake `script:` directive."""
    log_path = Path(sm.log[0])
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with open(log_path, "w") as log_f:
        n_c, n_u = link(
            sample_id=sm.params.sample_id,
            blast_file=Path(sm.input.blast),
            kraken_file=Path(sm.input.kraken),
            ktax_file=Path(sm.input.ktax),
            output_file=Path(sm.output.links),
            log_handle=log_f,
        )
        print(f"Done: {n_c + n_u} total links "
              f"({n_c} classified, {n_u} unclassified)", file=log_f)


def _from_cli() -> None:
    """Invocation path: standalone CLI for ad-hoc / debugging use."""
    import argparse
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--sample-id", required=True)
    p.add_argument("--blast", required=True, type=Path,
                   help="BLAST outfmt-6 file (with qcovs as 13th column)")
    p.add_argument("--kraken", required=True, type=Path,
                   help="Kraken2 per-sequence output")
    p.add_argument("--ktax", required=True, type=Path,
                   help="Kraken2 taxonomy lookup (ktaxonomy.tsv)")
    p.add_argument("--output", required=True, type=Path)
    args = p.parse_args()

    n_c, n_u = link(
        sample_id=args.sample_id,
        blast_file=args.blast,
        kraken_file=args.kraken,
        ktax_file=args.ktax,
        output_file=args.output,
    )
    print(f"Done: {n_c + n_u} total links "
          f"({n_c} classified, {n_u} unclassified)", file=sys.stderr)


# -----------------------------------------------------------------------------
# Entry-point dispatch.
#
# Snakemake `script:` directive: injects a `snakemake` object into module
# globals before exec'ing the script. We detect that and dispatch.
#
# CLI: no `snakemake` global; argparse takes over.
#
# This is checked at module-import time (NOT inside `if __name__ == "__main__":`)
# because Snakemake's exec mechanism doesn't reliably set __name__ to "__main__"
# across versions.
# -----------------------------------------------------------------------------
if "snakemake" in globals():
    _from_snakemake(snakemake)  # noqa: F821 -- injected by Snakemake
elif __name__ == "__main__":
    _from_cli()
